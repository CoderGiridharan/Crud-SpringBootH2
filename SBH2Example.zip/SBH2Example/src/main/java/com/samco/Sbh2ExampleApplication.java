package com.samco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sbh2ExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sbh2ExampleApplication.class, args);
	}

}
