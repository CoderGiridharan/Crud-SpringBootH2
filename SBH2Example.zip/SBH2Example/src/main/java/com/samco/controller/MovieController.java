package com.samco.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.samco.model.Movie;
import com.samco.service.MovieService;

@RestController
public class MovieController {
	
	 @Autowired
	    MovieService movieService;
	 
	    @GetMapping(value = "/movies", produces = MediaType.APPLICATION_XML_VALUE)
	    private List getAllMovies() {
	        return movieService.getAllMovies();
	    }
	 
	    @GetMapping(value ="/movies/{id}", produces = MediaType.APPLICATION_XML_VALUE)
	    private Movie getMovie(@PathVariable("id") int id) {
	        return movieService.getMovieById(id);
	    }
	 
	    @DeleteMapping(value = "/movies/{id}", produces = MediaType.APPLICATION_XML_VALUE)
	    private void deleteMovie(@PathVariable("id") int id) {
	        movieService.delete(id);
	    }
	 
	    @PostMapping(value = "/movies", produces = MediaType.APPLICATION_XML_VALUE)
	    private int saveMovie(@RequestBody Movie movie) {
	        movieService.saveOrUpdate(movie);
	        return movie.getId();
	    }
	
}
